package org.cap.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.cap.demo.dao.ICustomerDao;
import org.cap.demo.dao.IInventoryDao;
import org.cap.demo.model.Product;
@Service("inventoryService")
public class InventoryServiceImpl implements IInventoryService {

	@Autowired
	private IInventoryDao inventoryDao;
	@Autowired
	private ICustomerDao CustomerDao;
	
	@Override
	public List<Product> saveProduct(Product product) {
		
		inventoryDao.save(product);
		return inventoryDao.findAll();
	}


	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return inventoryDao.findAll();
	}


	

	
}
